#7. Write a Python program to find if a given string starts with a given character using Lambda.
#Sample Output:
#True
#False
s="abcdf"
def functionp7(s:str,chr:str):
    if s[0]==chr:
        print("True")
    else:
        print("True")    
functionp7(s,"a")