#11. Write a Python program to compute the sum of elements of an array of integers. Use the map() function.
l=[1, 2, 3, 4]
sumation=lambda x:sum(x)
print(sumation(l))

