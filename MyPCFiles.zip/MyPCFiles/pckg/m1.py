def add(a,b):
    print("Addition is: ")


    