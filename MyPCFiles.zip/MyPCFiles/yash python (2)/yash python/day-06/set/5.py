t={1,2,3,4}
i=int(input("item to be removed: "))
t.remove(i)
print(t)
