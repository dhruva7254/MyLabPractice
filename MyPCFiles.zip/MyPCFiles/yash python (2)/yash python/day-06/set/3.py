s=int(input("enter size of set: "))
t=set()
for a in range(s):
    e=int(input(f"enter element{a}: "))
    t.add(e)
print(t) 



