#20. Write a Python program to remove the intersection of a second set with a first set.
s1={1,2,3,4,5,11,13,7,8}
s2={1,2,3,4,5,6,7,12,8,9}
print(s1-(s2&s1))