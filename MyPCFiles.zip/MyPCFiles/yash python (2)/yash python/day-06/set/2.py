t={1,2,3,4}
for e in set(t):
    print(e)