#12. Write a Python program to remove all elements from a given set.
s1={1,2,3,4,5,6,7,8}
s1.clear()
print(s1)

