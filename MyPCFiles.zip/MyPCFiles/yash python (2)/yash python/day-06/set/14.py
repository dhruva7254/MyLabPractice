#14. Write a Python program to find the maximum and minimum values in a set.
s1={1,2,3,4,5,6,7,8}
l1=[]
for e in s1:
    l1.append(e)
print(max(l1))    
