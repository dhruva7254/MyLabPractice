#13. Write a Python program that uses frozensets.
#Note: Frozensets behave just like sets except they are immutable.
s1={1,2,3,4,5,6,7,8}
s2=frozenset(s1)
print(s2)
