#31. Write a Python program to get the key, value and item in a dictionary.
d={'item1': 45.50, 'item2':35, 'item3': 41.30, 'item4':55, 'item5': 24}
for key in d:
    print(key, d[key],  key,":",d[key])