#26. Write a Python program to count the values associated with a key in a dictionary.
#Expected Output:
#6
#2