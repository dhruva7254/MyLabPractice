n=int(input("enter size of dictonery: "))
d={}
for x in range(1,n+1):
   d[x]=x**2
print(d)    