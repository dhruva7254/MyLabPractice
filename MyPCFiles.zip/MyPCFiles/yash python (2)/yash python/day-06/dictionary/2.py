d={}
n=int(input("enter size of dict"))
for a in range(n):
    k=int(input("enter key: "))
    v=int(input("enter value: "))
    d[k]=v
print(d) 
   