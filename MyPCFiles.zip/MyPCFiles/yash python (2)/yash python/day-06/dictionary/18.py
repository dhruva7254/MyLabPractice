#18. Write a Python program to check if a dictionary is empty or not.
d={1:2}
print(len(d))
if len(d)==0:
    print("given dictonery is empty")
else:
    print("given dictonery is not empty")    