l1=[1,2,3,4,5]
l2=[1,4,9,16,25]
d=dict(zip(l1,l2))
print(d)