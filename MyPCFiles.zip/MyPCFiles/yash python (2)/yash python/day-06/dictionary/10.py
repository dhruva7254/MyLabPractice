d={2:2,1:3,3:3}
s=0
for key in d:
    s=s+d[key]
print(s)    