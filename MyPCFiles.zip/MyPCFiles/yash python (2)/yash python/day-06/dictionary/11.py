d={2:2,1:3,3:3}
p=1
for key in d:
    p=p*d[key]
print(p)    