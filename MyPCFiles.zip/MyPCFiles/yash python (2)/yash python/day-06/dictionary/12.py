d={1: 10, 2: 20, 3: 30, 4: 40}
key=int(input("enter key to be removed: "))
del d[key]
print(d)