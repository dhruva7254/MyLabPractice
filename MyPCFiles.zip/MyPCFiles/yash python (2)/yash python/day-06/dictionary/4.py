d={1: 10, 2: 20, 3: 30, 4: 40}
k=int(input("enter key: "))
if k in d:
    print(f"key:{k} exist")
else:
    print(f"key:{k} donot exist")