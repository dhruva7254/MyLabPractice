d={2:-2,1:-3,3:-3}
print(max(d.values()))
print(min(d.values()))