t1=(1,2,3)
s=""
for e in set(t1):
   s=s+str(e)
print(s)

