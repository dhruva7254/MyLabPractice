t1=(1,2,3,4)
x=int(input("enter elem to verify: "))
if x in t1:
     print(f"{x} exist in tupple")
else:
     print(f"{x} do not exist in tupple")