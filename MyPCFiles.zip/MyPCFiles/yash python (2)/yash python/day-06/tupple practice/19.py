t1=[(1,2),(2,3),(3,4)]
d={}
for idx in range(len(t1)):
    d[t1[idx][0]]=t1[idx][1]
print(d)    