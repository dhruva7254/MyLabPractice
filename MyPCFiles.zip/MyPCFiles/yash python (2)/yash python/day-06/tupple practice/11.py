n=[1,2]
t1=()
for e in n:
    t1=t1+(e,)
print(type(t1))