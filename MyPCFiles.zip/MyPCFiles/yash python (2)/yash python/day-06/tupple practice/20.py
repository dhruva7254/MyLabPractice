s=int(input("enter size of tupple: "))
t=()
for a in range(s):
    e=int(input(f"enter element{a}: "))
    t=t+(e,)
str(t)  
print(t)  