t1=[(1,2),(2,3),(3,4)]
for e in t1:
    print(list(e))