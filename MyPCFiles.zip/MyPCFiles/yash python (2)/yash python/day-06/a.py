t1=(9,9,9,9,9,23,45,67,67)
s=set()
l1=[]
for e1 in set(t1):
    if t1.count(e1)>1:
        s.add(e1)
print(s)


 
           