#2. display value 20 from the following tuple
t= ("Orange", [10, 20, 30], (5, 15, 25))
print(t[1][1])
