#3. Unpack the following tuple into 4 variables
t=(10, 20, 30, 40)
a=t[0]
b=t[1]
c=t[2]
d=t[3]
print(a,b,c,d)