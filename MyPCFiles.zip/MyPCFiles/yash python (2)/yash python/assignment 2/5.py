print(ord("a"))
print(chr(97))
for x in range(1,99):
    print(chr(x))
