x=2
y=5
z=0
print(x==2)
print(x!=5)
print(x!=5 & y>=5)
print(z!=0 | x==2)
print(not(y<10))