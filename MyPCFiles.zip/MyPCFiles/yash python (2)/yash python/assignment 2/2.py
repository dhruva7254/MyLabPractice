a=1/3
b=format(1/3,'.3f')
c=format(1/3,'.1f')
d=6*1/3
e=1/3+1/3+1/3+1/3+1/3+1/3
print(a,b,c,d,e)