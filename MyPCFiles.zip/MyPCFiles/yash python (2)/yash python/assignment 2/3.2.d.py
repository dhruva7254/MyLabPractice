n=int(input("enter size: "))
for idx in range(n):
  for idx2 in range(idx+1):
    print(idx2+1,end="")
  print("\n")
