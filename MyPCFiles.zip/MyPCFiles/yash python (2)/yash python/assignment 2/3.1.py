t=0
for x in range(10):
    s=int(input(f"enter integer {x+1}: "))
    t=t+s
avg=t/10
print(f"avg of integer is: {avg}")