n=int(input("enter no: "))
for a in range(1,n+1):
  print(a**3)
