x=10
y=34.4
print(x and y)
print(x or y)



