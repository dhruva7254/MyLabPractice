str=input("enter no: ")
s=0
for idx in range(0,len(str)):
 s=s+int(str[idx])
print('total digits:',int(len(str)))
print("sum of digits:",s)

