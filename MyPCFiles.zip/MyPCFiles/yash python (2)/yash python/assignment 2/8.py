a=int(input("enter first no: "))
b=int(input("enter first no: "))
c=int(input("enter first no: "))
total=a+b+c
print(total)