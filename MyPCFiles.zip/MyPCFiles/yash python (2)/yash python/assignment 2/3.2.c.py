n=int(input("enter size for pattern: "))
a=n-1
for x in range(n):
 print("10"*a,"1",sep="")
 a=a-1
