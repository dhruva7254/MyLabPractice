c=input("Do you have medical cause:(y or n)")
if c=="y":
  print("allow student to sit ")
elif c=="n":
  print("dont allow student to sit ")
else:
  print("invalid input")