n=abs(int(input("enter no: ")))
l=n%10
if (l%3==0) & (l>0):
   print("last digit of no is divisible by 3")
else:
   print("last digit of no is not divisible by 3")