s=0
for a in range(20):
    n=int(input("enter no: "))
    if n%2==0:
        s=s+n
print(s)        