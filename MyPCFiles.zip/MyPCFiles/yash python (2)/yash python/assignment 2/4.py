print("hello"," "*5)
print(" "*5,"hello")
print("#"*5,"hello","#"*5)
print(""*10)