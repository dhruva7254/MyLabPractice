a=format(22/7,'.5f')
print(a)