#42. Write a Python program to calculate the product of a given list of numbers using lambda.
l=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#Product of the said list numbers:
#3628800
#list2: [2.2, 4.12, 6.6, 8.1, 8.3]
#Product of the said list numbers:
#4021.8599520000007
s=1
for e in l:
    s=s*e
print(s)    