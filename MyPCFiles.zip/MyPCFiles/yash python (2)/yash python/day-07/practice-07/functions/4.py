#4. Write a Python program to reverse a string. 
#Sample String : "1234abcd"
#Expected Output : "dcba4321"
def function4(s:str):
    s1=s[::-1]
    return s1
print(function4("1234abcd"))