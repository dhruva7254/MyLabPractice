#8. Write a Python program to convert a given list of integers and a tuple of integers in a list of strings.
l=[1, 2, 3, 4]
print(list(map(lambda x:str(x),l)))