#14. Write a Python program to interleave two lists into another list randomly. Use the map() function.
l1=[1, 2, 3, 4, 5, 6, 7, 8]
l2=[2, 2, 3, 1, 2, 6, 7, 9]

