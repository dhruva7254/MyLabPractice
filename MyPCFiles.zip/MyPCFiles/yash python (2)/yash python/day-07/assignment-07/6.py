#WA function to take dictionary as parameter. Print all keys of the dictionary
def printeledictonery(d):
    for key in d:
        print(key)
d={1:2,2:3,3:4}
printeledictonery(d)        