#WA function to take a number as parameter and  print True if given number is even else print False
def evenotest(n):
    if n%2==0:
        print(f"{n} is evevn")
    else:
        print(f"{n} is odd")    
      
evenotest(5)