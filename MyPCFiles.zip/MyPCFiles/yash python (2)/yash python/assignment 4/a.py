l1 = [ 0 , 1]
x= l1[0]
print(x)
x, l1[x] = 1, 300
print(x)
print(l1)
