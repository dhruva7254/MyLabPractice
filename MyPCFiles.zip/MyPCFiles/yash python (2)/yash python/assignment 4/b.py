comp = [1, 2, ('aa', 'ab')]   < [1, 2, ('abc', 'a'), 4]
print(comp)
