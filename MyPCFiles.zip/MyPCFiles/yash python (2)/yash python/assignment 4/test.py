s=input("enter notes: ")
s=s.lower()
s1=set(s.split(""))
print(s1)
