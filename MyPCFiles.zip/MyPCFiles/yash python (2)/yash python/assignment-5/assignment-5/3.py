sa=input("enter first string: ")
sb=input("enter second string: ")
idm1=len(sa)//2
idm2=len(sb)//2
s1=sa[0]
s2=sb[0]
s3=sa[idm1]
s4=sb[idm2]
s5=sa[len(sa)-1]
s6=sb[len(sb)-1]
s=s1+s2+s3+s4+s5+s6
print(s)

