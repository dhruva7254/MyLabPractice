#19. Write a Python program to get the last part of a string before a specified character.
s="https://www.w3resource.com/python-exercises"
#https://www.w3resource.com/python
print(s.partition("-")[0])