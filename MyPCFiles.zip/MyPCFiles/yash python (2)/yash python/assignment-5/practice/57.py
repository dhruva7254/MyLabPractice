#57.Write a Python program to remove spaces from a given string.
s=input("enter string for removal of space: ")
print("".join(s.split(" ")))

    