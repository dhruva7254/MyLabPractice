#24. Write a Python program to check whether a string starts with specified 
#characters.(do both using library and without library)
s=input("enter string: ")
a=input("enter character: ")
if s[0]==a:
    print(f"enter string starts with {a}")
else:
    print(f"enter string dose not starts with{a}")
