#1. Write a Python program to calculate the length of a string.
#a. using built-in function
#b.without using built-in function
s=input("enter string: ")
print(len(s))
c=0
for e in s:
    c=c+1
print(c)    
