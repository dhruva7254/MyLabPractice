#54. Write a Python program to find the first repeated character in a given string 
#where the index of the first occurrence is smallest. Return the smallest index.
