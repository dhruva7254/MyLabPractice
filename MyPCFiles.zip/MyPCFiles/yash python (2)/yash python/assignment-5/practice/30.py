#30. Write a Python program to print the following numbers up to 2 decimal places.
#a. 123.45678
#b. 0.0000004
#c. 123
#. 123456789.9
n=float(input("enter no: "))
print(format(n,'.0f'))



