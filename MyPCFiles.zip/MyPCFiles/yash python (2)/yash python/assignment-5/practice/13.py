#13. Write a Python script that takes input from the user and displays that input back in upper and lower cases.
s=input("enter string: ")
print(s.upper())
print(s.lower())