n=input("enter hexadecimal no: ")
print(int(n,16))