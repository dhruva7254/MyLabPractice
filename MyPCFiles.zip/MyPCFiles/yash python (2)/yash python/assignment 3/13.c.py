h=input("enter hexadecimal: ")
f=float(h,16)
print(f)