print(isinstance((4**0.5),float))
    