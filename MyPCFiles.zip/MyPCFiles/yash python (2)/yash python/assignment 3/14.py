f=float(input("enter decimal value: "))
a=(f).as_integer_ratio()
print(f"{a[0]}/{a[1]}")

