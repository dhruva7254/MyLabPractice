#n=int(input("enter integer for coversion: "))
#print(f"Binary of integer {n}: ",bin(n))
#print(f"octal of integer {n}: ",oct(n))
#print(f"hexadecimal of integer {n}: ",hex(n))

n=input("enter binary no: ")
n=int(n,2)
print(f"octal of integer {n}: ",oct(n))
print(f"hexadecimal of integer {n}: ",hex(n))