m=float(input("enter persentage marks: "))
c=complex(input("enter complex no: "))
s=str(input("enter name: "))
print(m,"\n",c,"\n",s)