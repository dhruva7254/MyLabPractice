x=0
sys.getsizeof(x)