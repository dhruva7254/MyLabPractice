print(10 + True)
print(1578.67 + False)