print(isinstance(10,int))
print(isinstance(10,float))
print(isinstance(1,bool))
