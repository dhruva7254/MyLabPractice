n=input("enter octal no: ")
print(int(n,8))