n=input("enter binary no: ")
print(int(n,2))