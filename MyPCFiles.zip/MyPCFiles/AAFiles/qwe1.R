m="jhg"
print(m)
print("ghr")
# print
cat("ghr","ght")
cat("htr!")
paste("fhg","bht")
cat("fhg","bht")
v="ght"
v
yn=readline(prompt = "what is your name ?")
yn
rt=readline()
rt
print(yn)
print(class(yn))
efv=234
print(class(efv))
