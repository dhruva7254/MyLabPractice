cla = {'c1':'wer', 'c2':'fgr'}
cde = {'c1':'gre', 'c4':'hyt'}
print(cla-cde)
